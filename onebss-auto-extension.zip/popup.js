// popup.js - Điều khiển giao diện Extension Popup

document.addEventListener('DOMContentLoaded', async () => {
  const notOnebssNotice = document.getElementById('not-onebss-notice');
  const mainControls = document.getElementById('main-controls');
  const btnOpenOnebss = document.getElementById('btn-open-onebss');
  const inputKeyword = document.getElementById('input-keyword');
  const btnUpdateDetail = document.getElementById('btn-update-detail');
  const btnAutoFind = document.getElementById('btn-auto-find');
  const statusCard = document.getElementById('status-card');
  const resultsContainer = document.getElementById('results-container');
  const taskList = document.getElementById('task-list');

  // Lấy tab hiện tại
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const isOneBss = activeTab && activeTab.url && activeTab.url.includes('onebss.vnpt.vn');

  if (!isOneBss) {
    notOnebssNotice.classList.remove('hidden');
    mainControls.classList.add('hidden');

    btnOpenOnebss.addEventListener('click', () => {
      chrome.tabs.create({ url: 'https://onebss.vnpt.vn/#/home1' });
    });
    return;
  }

  // Tải từ khóa đã lưu từ storage
  chrome.storage.local.get(['onebssLeadKeyword'], (res) => {
    inputKeyword.value = res.onebssLeadKeyword || 'Lê Minh Tuấn';
  });

  // Tự động lưu cấu hình khi người dùng đổi tên/mã
  inputKeyword.addEventListener('input', () => {
    chrome.storage.local.set({ onebssLeadKeyword: inputKeyword.value.trim() });
  });

  function setStatus(text, type) {
    statusCard.className = 'status-box status-' + type;
    statusCard.textContent = text;
  }

  function renderTasks(tasks) {
    taskList.innerHTML = '';
    if (!tasks || tasks.length === 0) {
      resultsContainer.classList.add('hidden');
      return;
    }

    resultsContainer.classList.remove('hidden');
    tasks.forEach(t => {
      const item = document.createElement('div');
      item.className = 'task-item';
      item.innerHTML = `
        <div class="task-item-title">TT ${t.thuTu}: ${t.tenCongViec}</div>
        <div class="task-item-meta">
          <span class="badge ${t.isUpdated ? 'badge-updated' : 'badge-ok'}">${t.trangThai}</span>
          <span class="time-meta">Kết thúc: <strong>${t.ketThuc || 'Chưa rõ'}</strong></span>
        </div>
      `;
      taskList.appendChild(item);
    });
  }

  async function sendAction(action) {
    const keyword = inputKeyword.value.trim();
    if (!keyword) {
      setStatus('Vui lòng nhập tên người chủ trì hoặc mã nhân viên!', 'error');
      inputKeyword.focus();
      return;
    }

    btnUpdateDetail.disabled = true;
    btnAutoFind.disabled = true;
    resultsContainer.classList.add('hidden');
    taskList.innerHTML = '';
    setStatus('Đang thực hiện, vui lòng chờ...', 'loading');

    try {
      chrome.tabs.sendMessage(activeTab.id, {
        action,
        payload: { keyword }
      }, (response) => {
        btnUpdateDetail.disabled = false;
        btnAutoFind.disabled = false;

        if (chrome.runtime.lastError) {
          setStatus('Chưa kết nối được với trang OneBSS. Hãy tải lại (F5) trang OneBSS rồi thử lại.', 'error');
          return;
        }

        if (!response || !response.success) {
          setStatus(response && response.error ? response.error : 'Có lỗi xảy ra hoặc hết thời gian phản hồi.', 'error');
        } else {
          setStatus(response.message || 'Thao tác hoàn tất thành công!', 'success');
          renderTasks(response.tasks);
        }
      });
    } catch (err) {
      btnUpdateDetail.disabled = false;
      btnAutoFind.disabled = false;
      setStatus('Lỗi: ' + (err.message || String(err)), 'error');
    }
  }

  btnUpdateDetail.addEventListener('click', () => sendAction('PROCESS_DETAIL'));
  btnAutoFind.addEventListener('click', () => sendAction('AUTO_FIND_PROCESS'));
});
