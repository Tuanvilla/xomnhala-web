// content-bridge.js - Cầu nối trung gian giữa Chrome Extension và trang web OneBSS

(function () {
  console.log('[OneBSS Auto] Content Bridge đã được nạp.');

  // 1. Nhúng injected.js vào trang web (MAIN world)
  function injectMainScript() {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('injected.js');
    script.onload = function () {
      this.remove();
    };
    (document.head || document.documentElement).appendChild(script);
  }
  injectMainScript();

  // 2. Quản lý Request - Response giữa Bridge và Injected script
  const pendingRequests = new Map();

  function callInjected(action, payload) {
    return new Promise((resolve, reject) => {
      const requestId = 'req_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
      const timer = setTimeout(() => {
        if (pendingRequests.has(requestId)) {
          pendingRequests.delete(requestId);
          reject(new Error('Hết thời gian chờ phản hồi từ trang web (Timeout).'));
        }
      }, 45000);

      pendingRequests.set(requestId, { resolve, reject, timer });
      window.postMessage({
        source: 'ONEBSS_BRIDGE',
        action,
        requestId,
        payload
      }, '*');
    });
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || event.data.source !== 'ONEBSS_INJECTED') return;
    const { requestId, ...data } = event.data;
    if (pendingRequests.has(requestId)) {
      const { resolve, timer } = pendingRequests.get(requestId);
      clearTimeout(timer);
      pendingRequests.delete(requestId);
      resolve(data);
    }
  });

  // 3. Lắng nghe tin nhắn từ Popup Extension
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'PING') {
      sendResponse({ status: 'OK' });
      return true;
    }

    callInjected(request.action, request.payload)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ success: false, error: err.message }));

    return true; // Báo hiệu phản hồi bất đồng bộ (async)
  });

  // 4. Tạo Widget Nổi (Floating Widget) trực tiếp trên trang OneBSS
  function initFloatingWidget() {
    if (document.getElementById('onebss-auto-root')) return;

    const root = document.createElement('div');
    root.id = 'onebss-auto-root';
    root.innerHTML = `
      <div id="onebss-auto-badge" title="Mở bảng OneBSS Auto">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5">
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
        </svg>
        <span>OneBSS Auto</span>
      </div>

      <div id="onebss-auto-panel" class="onebss-hidden">
        <div class="onebss-panel-header">
          <div class="onebss-title">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
              <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
            </svg>
            <strong>OneBSS Auto</strong>
          </div>
          <button id="onebss-close-btn" title="Thu nhỏ">&times;</button>
        </div>

        <div class="onebss-panel-body">
          <div class="onebss-field">
            <label for="onebss-name-input">Người chủ trì (Tên hoặc Mã NV):</label>
            <input type="text" id="onebss-name-input" placeholder="Ví dụ: Lê Minh Tuấn hoặc VNPT031453" />
          </div>

          <div class="onebss-buttons">
            <button id="onebss-btn-update" class="onebss-btn onebss-btn-primary">
              ⚡ Xử lý việc Chủ trì (+1h)
            </button>
            <button id="onebss-btn-auto" class="onebss-btn onebss-btn-secondary">
              🔍 Tự động tìm ca & Xử lý
            </button>
          </div>

          <div id="onebss-status-box" class="onebss-status-idle">
            Sẵn sàng rà soát ca trực.
          </div>

          <div id="onebss-task-list" class="onebss-task-list"></div>
        </div>

        <div class="onebss-panel-footer">
          <span>Quy tắc: Chuyển Đã xử lý & kết thúc sau 1h</span>
        </div>
      </div>
    `;

    document.body.appendChild(root);

    const badge = document.getElementById('onebss-auto-badge');
    const panel = document.getElementById('onebss-auto-panel');
    const closeBtn = document.getElementById('onebss-close-btn');
    const nameInput = document.getElementById('onebss-name-input');
    const btnUpdate = document.getElementById('onebss-btn-update');
    const btnAuto = document.getElementById('onebss-btn-auto');
    const statusBox = document.getElementById('onebss-status-box');
    const taskList = document.getElementById('onebss-task-list');

    // Nạp cấu hình tên đã lưu từ storage
    chrome.storage.local.get(['onebssLeadKeyword'], (res) => {
      nameInput.value = res.onebssLeadKeyword || 'Lê Minh Tuấn';
    });

    nameInput.addEventListener('input', () => {
      chrome.storage.local.set({ onebssLeadKeyword: nameInput.value.trim() });
    });

    badge.addEventListener('click', () => {
      panel.classList.toggle('onebss-hidden');
    });

    closeBtn.addEventListener('click', () => {
      panel.classList.add('onebss-hidden');
    });

    function setStatus(text, type) {
      statusBox.className = 'onebss-status-' + type;
      statusBox.textContent = text;
    }

    function renderTasks(tasks) {
      taskList.innerHTML = '';
      if (!tasks || tasks.length === 0) return;

      tasks.forEach(t => {
        const item = document.createElement('div');
        item.className = 'onebss-task-item';
        item.innerHTML = `
          <div class="onebss-task-title">TT ${t.thuTu}: ${t.tenCongViec}</div>
          <div class="onebss-task-meta">
            <span class="onebss-badge ${t.isUpdated ? 'badge-updated' : 'badge-ok'}">${t.trangThai}</span>
            <span class="onebss-time">Kết thúc: <strong>${t.ketThuc || 'Chưa có'}</strong></span>
          </div>
        `;
        taskList.appendChild(item);
      });
    }

    async function handleAction(action) {
      const keyword = nameInput.value.trim();
      if (!keyword) {
        setStatus('Vui lòng nhập tên người chủ trì hoặc mã nhân viên!', 'error');
        nameInput.focus();
        return;
      }

      btnUpdate.disabled = true;
      btnAuto.disabled = true;
      taskList.innerHTML = '';
      setStatus('Đang xử lý, vui lòng chờ trong giây lát...', 'loading');

      try {
        const res = await callInjected(action, { keyword });
        if (!res.success) {
          setStatus(res.error || 'Có lỗi xảy ra trong quá trình xử lý.', 'error');
        } else {
          setStatus(res.message || 'Hoàn tất cập nhật!', 'success');
          renderTasks(res.tasks);
        }
      } catch (err) {
        setStatus('Lỗi: ' + (err.message || String(err)), 'error');
      } finally {
        btnUpdate.disabled = false;
        btnAuto.disabled = false;
      }
    }

    btnUpdate.addEventListener('click', () => handleAction('PROCESS_DETAIL'));
    btnAuto.addEventListener('click', () => handleAction('AUTO_FIND_PROCESS'));
  }

  // Khởi động widget khi trang tải xong
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initFloatingWidget);
  } else {
    initFloatingWidget();
  }
})();
