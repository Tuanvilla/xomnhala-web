# OneBSS Auto - Tiện ích mở rộng Chrome (Chrome Extension)

Tiện ích mở rộng trình duyệt giúp tự động rà soát ca trực OneBSS (VNPT), tìm các đầu việc do nhân sự chỉ định đóng vai trò **Chủ trì**, chuyển trạng thái sang **Đã xử lý** và tự động tính toán mốc giờ kết thúc sau đúng 1 giờ tính từ đầu khung công việc.

---

## 1. Ưu điểm khi dùng Chrome Extension

- **Không cần cài đặt môi trường:** Đồng nghiệp không cần cài Node.js, Python hay dòng lệnh phức tạp.
- **An toàn tuyệt đối:** Sử dụng trực tiếp phiên đăng nhập SSO đã có trên trình duyệt của người dùng, không lưu mật khẩu và không lo hết hạn token.
- **Linh hoạt nhân sự:** Bất kỳ ai cũng có thể đổi Tên hoặc Mã nhân viên trong ô cấu hình một lần duy nhất; hệ thống tự lưu cho các ca sau.
- **2 cách kích hoạt tiện lợi:**
  - Bấm vào biểu tượng tiện ích trên thanh công cụ của Chrome.
  - Bấm vào nút nổi **⚡ OneBSS Auto** hiển thị trực tiếp ở góc dưới bên phải màn hình OneBSS.

---

## 2. Hướng dẫn cài đặt vào Chrome / Edge (3 bước đơn giản)

1. **Mở trang quản lý tiện ích:**
   - Trên Chrome: Truy cập đường dẫn `chrome://extensions/`
   - Trên Edge: Truy cập đường dẫn `edge://extensions/`
2. **Bật chế độ dành cho nhà phát triển:**
   - Gạt công tắc **Developer mode** (Chế độ dành cho nhà phát triển) ở góc trên bên phải sang trạng thái **Bật (ON)**.
3. **Tải tiện ích:**
   - Bấm nút **Load unpacked** (Tải tiện ích đã giải nén).
   - Chọn đúng thư mục: `skills/one-bss-auto/extension` (hoặc thư mục copy chứa extension này).
   - Biểu tượng **OneBSS Auto** sẽ xuất hiện trên thanh công cụ của trình duyệt. Bạn có thể bấm biểu tượng cái ghim để ghim tiện ích ra ngoài cho dễ dùng.

---

## 3. Hướng dẫn sử dụng cho đồng nghiệp

### Bước 1: Nhập Tên hoặc Mã nhân viên
- Mở OneBSS và đăng nhập tài khoản cá nhân.
- Bấm vào tiện ích hoặc nút nổi **⚡ OneBSS Auto**.
- Nhập Tên (ví dụ: `Lê Minh Tuấn`, `Nguyễn Văn A`) hoặc Mã nhân viên (ví dụ: `VNPT031453`). Tiện ích sẽ tự động ghi nhớ, các lần sau không cần nhập lại.

### Bước 2: Kích hoạt xử lý
- **Cách 1 - Khi đang mở chi tiết ca trực:**
  - Bấm nút **⚡ Xử lý việc Chủ trì (+1h)**.
  - Tiện ích tự động quét danh sách việc, đổi trạng thái sang "Đã xử lý", điền giờ kết thúc và lưu lên hệ thống.
- **Cách 2 - Khi đang ở trang chủ hoặc danh sách ca:**
  - Bấm nút **🔍 Tự động tìm ca & Xử lý**.
  - Tiện ích sẽ tự tìm ca trực mới nhất có tên bạn, mở chi tiết và thực hiện cập nhật.

---

## 4. Quy tắc tính toán thời gian (+1h)

- **Khung ban ngày:** Ví dụ `17h00 - 19h00` -> Giờ kết thúc: `18:00`.
- **Khung 21h - 23h:** Giờ kết thúc: `22:00`.
- **Khung ca đêm qua ngày:**
  - `24h00 - 02h00` -> Giờ kết thúc: `01:00` của ngày hôm sau (+1 ngày).
  - Khung rạng sáng (ví dụ `04h00 - 06h00`) -> Giờ kết thúc: `05:00` của ngày hôm sau.

---

## 5. Lưu ý & Khắc phục lỗi

- Nếu tiện ích báo *"Chưa kết nối được với trang OneBSS"*, chỉ cần nhấn phím **F5** để tải lại trang OneBSS rồi bấm chạy lại.
- Khi chia sẻ cho máy khác, bạn chỉ cần nén toàn bộ thư mục `extension` này thành file `.zip`, gửi cho đồng nghiệp giải nén và chọn **Load unpacked** như hướng dẫn ở Mục 2.
