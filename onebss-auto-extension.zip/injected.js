// injected.js - Chạy trực tiếp trong ngữ cảnh trang OneBSS (MAIN world)
// Có toàn quyền truy cập Vue Component và dữ liệu hệ thống

(function () {
  console.log('[OneBSS Auto] Injected script đã sẵn sàng.');

  function findVue(el) {
    while (el) {
      if (el.__vue__) return el.__vue__;
      el = el.parentElement;
    }
    return null;
  }

  function findPvm() {
    const gridEl = document.querySelector('.grid-ext');
    if (gridEl) {
      let el = gridEl;
      while (el) {
        if (el.__vue__) {
          if (el.__vue__.$parent && el.__vue__.$parent.dsCongViec) return el.__vue__.$parent;
          if (el.__vue__.dsCongViec) return el.__vue__;
        }
        el = el.parentElement;
      }
    }

    // Quét toàn bộ DOM nếu bảng chưa gắn trực tiếp
    const all = document.querySelectorAll('div, section, main');
    for (const el of all) {
      if (el.__vue__ && el.__vue__.dsCongViec && typeof el.__vue__.onGhiLai === 'function') {
        return el.__vue__;
      }
    }
    return null;
  }

  function calculateTargetEndTime(tenCongViec, baseDateStr) {
    const match = tenCongViec.match(/(?:Lúc\s*)?(\d{1,2})[h:](\d{0,2})\s*[-–]\s*(\d{1,2})[h:](\d{0,2})/i);
    if (!match) return null;

    let startH = parseInt(match[1], 10);
    let startM = match[2] ? parseInt(match[2], 10) : 0;

    let dStr, mStr, yStr;
    if (baseDateStr && baseDateStr.includes('/')) {
      [dStr, mStr, yStr] = baseDateStr.split('/');
    } else {
      const now = new Date();
      dStr = String(now.getDate()).padStart(2, '0');
      mStr = String(now.getMonth() + 1).padStart(2, '0');
      yStr = String(now.getFullYear());
    }

    let day = parseInt(dStr, 10);
    let month = parseInt(mStr, 10);
    let year = parseInt(yStr, 10);
    let targetDate = new Date(year, month - 1, day, 0, 0, 0);

    let endH, endM = startM;
    if (startH === 24 || startH === 0) {
      targetDate.setDate(targetDate.getDate() + 1);
      endH = 1;
    } else if (startH < 7) {
      targetDate.setDate(targetDate.getDate() + 1);
      endH = startH + 1;
    } else {
      endH = startH + 1;
      if (endH >= 24) {
        endH = endH - 24;
        targetDate.setDate(targetDate.getDate() + 1);
      }
    }

    const pad = n => String(n).padStart(2, '0');
    const dFormatted = `${pad(targetDate.getDate())}/${pad(targetDate.getMonth() + 1)}/${targetDate.getFullYear()}`;
    const tFormatted = `${pad(endH)}:${pad(endM)}`;
    return `${dFormatted} ${tFormatted}`;
  }

  function isUserLead(task, keyword) {
    if (!keyword || !keyword.trim()) return false;
    const kw = keyword.trim().toLowerCase();
    const text = (task.nguoiThucHien || '').toLowerCase();
    const selected = Array.isArray(task.dsNguoiThucHienSelected) ? task.dsNguoiThucHienSelected : [];

    // Kiểm tra danh sách phân công
    const matchSelected = selected.some(s => {
      const ten = (s.TEN_NV || '').toLowerCase();
      const ma = (s.MA_NV || '').toLowerCase();
      const id = String(s.NHANVIEN_ID || '');
      const isLead = (s.NHIEMVU_ID === 1 || s.TEN_NHIEMVU === 'Chủ trì' || s.ROLE === 'Chủ trì');
      const isPerson = ten.includes(kw) || ma.includes(kw) || id.includes(kw);
      return isPerson && isLead;
    });

    // Kiểm tra chuỗi hiển thị
    const matchText = text.includes(kw) && (text.includes('chủ trì') || text.includes('(chủ trì)'));

    return matchSelected || matchText;
  }

  async function processDetailTasks(keyword) {
    const pvm = findPvm();
    if (!pvm) {
      return {
        success: false,
        error: 'Không tìm thấy bảng công việc ca trực. Hãy đảm bảo bạn đang mở trang Chi tiết ca trực.'
      };
    }

    const allTasks = pvm.dsCongViec || [];
    const leadTasks = [];

    for (const task of allTasks) {
      if (isUserLead(task, keyword)) {
        const baseDate = task.ngayGiao || pvm.ngayTruc || '';
        const targetKetThuc = calculateTargetEndTime(task.tenCongViec, baseDate);
        const isDone = String(task.trangThaiId) === '667';
        const isTimeMatch = task.ketThuc === targetKetThuc;

        leadTasks.push({
          task,
          rowKey: task.rowKey,
          thuTu: task.thuTu,
          tenCongViec: task.tenCongViec,
          trangThaiHienTai: task.trangThai,
          ketThucHienTai: task.ketThuc,
          targetKetThuc: targetKetThuc,
          needsUpdate: !isDone || !isTimeMatch
        });
      }
    }

    if (leadTasks.length === 0) {
      return {
        success: true,
        updatedCount: 0,
        tasks: [],
        message: `Không tìm thấy công việc nào do "${keyword}" Chủ trì trong ca trực này.`
      };
    }

    const tasksToUpdate = leadTasks.filter(t => t.needsUpdate);

    if (tasksToUpdate.length === 0) {
      return {
        success: true,
        updatedCount: 0,
        tasks: leadTasks.map(t => ({
          thuTu: t.thuTu,
          tenCongViec: t.tenCongViec,
          trangThai: t.trangThaiHienTai,
          ketThuc: t.ketThucHienTai,
          isUpdated: false
        })),
        message: `Tất cả ${leadTasks.length} đầu việc Chủ trì đã ở trạng thái Đã xử lý với đúng khung giờ (+1h)!`
      };
    }

    // Chọn hàng cần sửa
    const rowsToEdit = tasksToUpdate.map(t => pvm.getRowByKey(String(t.rowKey))).filter(Boolean);
    pvm.selectedItems = rowsToEdit;

    // Kích hoạt sửa
    if (typeof pvm.onSua === 'function') {
      await pvm.onSua();
    }

    // Cập nhật giá trị
    for (const t of tasksToUpdate) {
      const key = String(t.rowKey);
      pvm.onTrangThaiChanged(key, 667); // 667 = Đã xử lý
      if (t.targetKetThuc) {
        pvm.onKetThucChanged(key, t.targetKetThuc);
      }
    }

    // Xác thực
    if (typeof pvm.validateControls === 'function') {
      const err = pvm.validateControls();
      if (err) {
        return { success: false, error: 'Lỗi xác thực dữ liệu trên form: ' + err };
      }
    }

    // Ghi lại vào hệ thống
    if (typeof pvm.onGhiLai === 'function') {
      await pvm.onGhiLai();
    }

    return {
      success: true,
      updatedCount: tasksToUpdate.length,
      tasks: leadTasks.map(t => ({
        thuTu: t.thuTu,
        tenCongViec: t.tenCongViec,
        trangThai: 'Đã xử lý',
        ketThuc: t.targetKetThuc || t.ketThucHienTai,
        isUpdated: t.needsUpdate
      })),
      message: `Đã cập nhật thành công ${tasksToUpdate.length}/${leadTasks.length} việc Chủ trì sang Đã xử lý (+1h).`
    };
  }

  async function autoFindAndProcess(keyword) {
    const currentHash = window.location.hash || '';

    // Nếu đang ở chi tiết ca trực thì xử lý luôn
    if (currentHash.includes('chi-tiet-thong-tin-ca-truc')) {
      return await processDetailTasks(keyword);
    }

    // Nếu chưa ở trang danh sách, chuyển hướng về danh sách ca trực
    if (!currentHash.includes('ds-thong-tin-ca-truc')) {
      window.location.hash = '#/ha-tang/ds-thong-tin-ca-truc';
    }

    // Chờ grid danh sách tải
    const maxWait = 15;
    let foundShift = null;

    for (let i = 0; i < maxWait; i++) {
      await new Promise(r => setTimeout(r, 1000));
      const gridEl = document.querySelector('.grid-ext');
      if (gridEl) {
        const vm = findVue(gridEl);
        if (vm) {
          const ds = (vm.ej2Instances && vm.ej2Instances.dataSource) || vm.dataSource || [];
          if (Array.isArray(ds) && ds.length > 0) {
            const kw = keyword.toLowerCase();
            const matches = ds.filter(item => {
              const str = JSON.stringify(item).toLowerCase();
              return str.includes(kw);
            });
            if (matches.length > 0) {
              matches.sort((a, b) => (b.id || 0) - (a.id || 0));
              foundShift = matches[0];
              break;
            }
          }
        }
      }
    }

    if (!foundShift || !foundShift.id) {
      return {
        success: false,
        error: `Không tìm thấy ca trực nào của "${keyword}" trong danh sách hiện tại. Hãy mở thủ công ca trực hoặc tìm kiếm theo ngày trên web.`
      };
    }

    // Chuyển hướng tới chi tiết ca trực vừa tìm được
    window.location.hash = `#/ha-tang/chi-tiet-thong-tin-ca-truc/${foundShift.id}`;

    // Chờ trang chi tiết tải xong
    for (let i = 0; i < 15; i++) {
      await new Promise(r => setTimeout(r, 1000));
      const pvm = findPvm();
      if (pvm && Array.isArray(pvm.dsCongViec) && pvm.dsCongViec.length > 0) {
        break;
      }
    }

    // Thực hiện cập nhật
    return await processDetailTasks(keyword);
  }

  // Lắng nghe lệnh từ content-bridge
  window.addEventListener('message', async (event) => {
    if (event.source !== window || !event.data || event.data.source !== 'ONEBSS_BRIDGE') return;

    const { action, requestId, payload } = event.data;

    try {
      if (action === 'PROCESS_DETAIL') {
        const res = await processDetailTasks(payload.keyword);
        window.postMessage({ source: 'ONEBSS_INJECTED', requestId, ...res }, '*');
      } else if (action === 'AUTO_FIND_PROCESS') {
        const res = await autoFindAndProcess(payload.keyword);
        window.postMessage({ source: 'ONEBSS_INJECTED', requestId, ...res }, '*');
      } else if (action === 'GET_PAGE_INFO') {
        const pvm = findPvm();
        const hash = window.location.hash || '';
        window.postMessage({
          source: 'ONEBSS_INJECTED',
          requestId,
          success: true,
          hash: hash,
          isDetailPage: hash.includes('chi-tiet-thong-tin-ca-truc'),
          hasPvm: !!pvm,
          taskCount: pvm && pvm.dsCongViec ? pvm.dsCongViec.length : 0
        }, '*');
      }
    } catch (err) {
      window.postMessage({
        source: 'ONEBSS_INJECTED',
        requestId,
        success: false,
        error: err.message || String(err)
      }, '*');
    }
  });
})();
