// injected.js - Chạy trực tiếp trong ngữ cảnh trang OneBSS (MAIN world)
// Có toàn quyền truy cập Vue Component và dữ liệu hệ thống

(function () {
  console.log('[OneBSS Auto] Injected script đã sẵn sàng.');

  function findVue(el) {
    while (el) {
      if (el.__vue__) return el.__vue__;
      el = el.parentElement;
    }
    return null;
  }

  function findPvm() {
    const gridEl = document.querySelector('.grid-ext');
    if (gridEl) {
      let el = gridEl;
      while (el) {
        if (el.__vue__) {
          if (el.__vue__.$parent && el.__vue__.$parent.dsCongViec) return el.__vue__.$parent;
          if (el.__vue__.dsCongViec) return el.__vue__;
        }
        el = el.parentElement;
      }
    }

    // Quét toàn bộ DOM nếu bảng chưa gắn trực tiếp
    const all = document.querySelectorAll('div, section, main');
    for (const el of all) {
      if (el.__vue__ && el.__vue__.dsCongViec && typeof el.__vue__.onGhiLai === 'function') {
        return el.__vue__;
      }
    }
    return null;
  }

  // Lấy thời gian thực tế theo múi giờ Việt Nam (Asia/Ho_Chi_Minh)
  function getVNTimeInfo() {
    const now = new Date();
    const vnFormatter = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Ho_Chi_Minh',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
    const parts = vnFormatter.formatToParts(now);
    const getPart = type => parts.find(p => p.type === type).value;
    const day = getPart('day');
    const month = getPart('month');
    const year = getPart('year');
    const hours = parseInt(getPart('hour'), 10);
    const minutes = parseInt(getPart('minute'), 10);

    const todayStr = `${day}/${month}/${year}`;

    const d = new Date(parseInt(year, 10), parseInt(month, 10) - 1, parseInt(day, 10));
    d.setDate(d.getDate() - 1);
    const pad = n => String(n).padStart(2, '0');
    const yesterdayStr = `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;

    return {
      hours,
      minutes,
      todayStr,
      yesterdayStr
    };
  }

  function parseDateDDMMYYYY(str) {
    if (!str || typeof str !== 'string') return 0;
    const parts = str.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (!parts) return 0;
    const d = parseInt(parts[1], 10);
    const m = parseInt(parts[2], 10);
    const y = parseInt(parts[3], 10);
    return new Date(y, m - 1, d).getTime();
  }

  function normalizeDateDDMMYYYY(val) {
    if (!val) return null;
    val = String(val).trim();
    const ddmmyyyy = val.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (ddmmyyyy) {
      const pad = n => String(n).padStart(2, '0');
      return `${pad(ddmmyyyy[1])}/${pad(ddmmyyyy[2])}/${ddmmyyyy[3]}`;
    }
    const yyyymmdd = val.match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
    if (yyyymmdd) {
      const pad = n => String(n).padStart(2, '0');
      return `${pad(yyyymmdd[3])}/${pad(yyyymmdd[2])}/${yyyymmdd[1]}`;
    }
    return null;
  }

  // Lấy ngày trực chính xác của ca hiện tại, không dùng task.ngayGiao (ngày giao mẫu)
  function getShiftDate(pvm) {
    // 1. Kiểm tra trên Vue component cha hoặc component bảng công việc
    if (pvm) {
      const candidates = [
        pvm.ngayTruc,
        pvm.model && pvm.model.ngayTruc,
        pvm.thongTinCaTruc && pvm.thongTinCaTruc.ngayTruc,
        pvm.$parent && pvm.$parent.ngayTruc,
        pvm.$parent && pvm.$parent.model && pvm.$parent.model.ngayTruc,
        pvm.$parent && pvm.$parent.thongTinCaTruc && pvm.$parent.thongTinCaTruc.ngayTruc
      ];
      for (const cand of candidates) {
        const norm = normalizeDateDDMMYYYY(cand);
        if (norm) return norm;
      }
    }

    // 2. Tìm trong ô nhập Ngày trực trên DOM
    const allInputs = Array.from(document.querySelectorAll('input'));
    for (const input of allInputs) {
      const val = (input.value || '').trim();
      const norm = normalizeDateDDMMYYYY(val);
      if (norm) {
        const parent = input.closest('.form-group, .row, .col, div, td');
        if (parent && parent.innerText && parent.innerText.includes('Ngày trực')) {
          return norm;
        }
      }
    }

    // 3. Quét input có id/name chứa ngaytruc
    for (const input of allInputs) {
      const val = (input.value || '').trim();
      const norm = normalizeDateDDMMYYYY(val);
      if (norm) {
        const idOrName = (input.name || input.id || '').toLowerCase();
        if (idOrName.includes('ngaytruc') || idOrName.includes('ngay_truc')) {
          return norm;
        }
      }
    }

    // 4. Mặc định lấy theo thời gian thực tế VN (nếu ca đêm < 8h thì lấy hôm qua)
    const timeInfo = getVNTimeInfo();
    return timeInfo.hours < 8 ? timeInfo.yesterdayStr : timeInfo.todayStr;
  }

  function calculateTargetEndTime(tenCongViec, baseDateStr) {
    const match = tenCongViec.match(/(?:Lúc\s*)?(\d{1,2})[h:](\d{0,2})\s*[-–]\s*(\d{1,2})[h:](\d{0,2})/i);
    if (!match) return null;

    let startH = parseInt(match[1], 10);
    let startM = match[2] ? parseInt(match[2], 10) : 0;

    let dStr, mStr, yStr;
    if (baseDateStr && baseDateStr.includes('/')) {
      [dStr, mStr, yStr] = baseDateStr.split('/');
    } else {
      const timeInfo = getVNTimeInfo();
      [dStr, mStr, yStr] = timeInfo.todayStr.split('/');
    }

    let day = parseInt(dStr, 10);
    let month = parseInt(mStr, 10);
    let year = parseInt(yStr, 10);
    let targetDate = new Date(year, month - 1, day, 0, 0, 0);

    let endH, endM = startM;
    if (startH === 24 || startH === 0) {
      targetDate.setDate(targetDate.getDate() + 1);
      endH = 1;
    } else if (startH < 7) {
      targetDate.setDate(targetDate.getDate() + 1);
      endH = startH + 1;
    } else {
      endH = startH + 1;
      if (endH >= 24) {
        endH = endH - 24;
        targetDate.setDate(targetDate.getDate() + 1);
      }
    }

    const pad = n => String(n).padStart(2, '0');
    const dFormatted = `${pad(targetDate.getDate())}/${pad(targetDate.getMonth() + 1)}/${targetDate.getFullYear()}`;
    const tFormatted = `${pad(endH)}:${pad(endM)}`;
    return `${dFormatted} ${tFormatted}`;
  }

  function isUserLead(task, keyword) {
    if (!keyword || !keyword.trim()) return false;
    const kw = keyword.trim().toLowerCase();
    const text = (task.nguoiThucHien || '').toLowerCase();
    const selected = Array.isArray(task.dsNguoiThucHienSelected) ? task.dsNguoiThucHienSelected : [];

    // Kiểm tra danh sách phân công
    const matchSelected = selected.some(s => {
      const ten = (s.TEN_NV || '').toLowerCase();
      const ma = (s.MA_NV || '').toLowerCase();
      const id = String(s.NHANVIEN_ID || '');
      const isLead = (s.NHIEMVU_ID === 1 || s.TEN_NHIEMVU === 'Chủ trì' || s.ROLE === 'Chủ trì');
      const isPerson = ten.includes(kw) || ma.includes(kw) || id.includes(kw);
      return isPerson && isLead;
    });

    // Kiểm tra chuỗi hiển thị
    const matchText = text.includes(kw) && (text.includes('chủ trì') || text.includes('(chủ trì)'));

    return matchSelected || matchText;
  }

  async function processDetailTasks(keyword) {
    const pvm = findPvm();
    if (!pvm) {
      return {
        success: false,
        error: 'Không tìm thấy bảng công việc ca trực. Hãy đảm bảo bạn đang mở trang Chi tiết ca trực.'
      };
    }

    const shiftDate = getShiftDate(pvm);
    console.log('[OneBSS Auto] Ngày ca trực xác định:', shiftDate);

    const allTasks = pvm.dsCongViec || [];
    const leadTasks = [];

    for (const task of allTasks) {
      if (isUserLead(task, keyword)) {
        // Dùng ngày ca trực thực tế, TUYỆT ĐỐI không dùng task.ngayGiao (ngày giao mẫu 01/11/2026)
        const targetKetThuc = calculateTargetEndTime(task.tenCongViec, shiftDate);
        const isDone = String(task.trangThaiId) === '667';
        const isTimeMatch = task.ketThuc === targetKetThuc;

        leadTasks.push({
          task,
          rowKey: task.rowKey,
          thuTu: task.thuTu,
          tenCongViec: task.tenCongViec,
          trangThaiHienTai: task.trangThai,
          ketThucHienTai: task.ketThuc,
          targetKetThuc: targetKetThuc,
          needsUpdate: !isDone || !isTimeMatch
        });
      }
    }

    if (leadTasks.length === 0) {
      return {
        success: true,
        updatedCount: 0,
        tasks: [],
        message: `Không tìm thấy công việc nào do "${keyword}" Chủ trì trong ca trực ngày ${shiftDate}.`
      };
    }

    const tasksToUpdate = leadTasks.filter(t => t.needsUpdate);

    if (tasksToUpdate.length === 0) {
      return {
        success: true,
        updatedCount: 0,
        tasks: leadTasks.map(t => ({
          thuTu: t.thuTu,
          tenCongViec: t.tenCongViec,
          trangThai: t.trangThaiHienTai,
          ketThuc: t.ketThucHienTai,
          isUpdated: false
        })),
        message: `Tất cả ${leadTasks.length} đầu việc Chủ trì (ngày ${shiftDate}) đã ở trạng thái Đã xử lý với đúng khung giờ (+1h)!`
      };
    }

    // Chọn hàng cần sửa
    const rowsToEdit = tasksToUpdate.map(t => pvm.getRowByKey(String(t.rowKey))).filter(Boolean);
    pvm.selectedItems = rowsToEdit;

    // Kích hoạt sửa
    if (typeof pvm.onSua === 'function') {
      await pvm.onSua();
    }

    // Cập nhật giá trị
    for (const t of tasksToUpdate) {
      const key = String(t.rowKey);
      pvm.onTrangThaiChanged(key, 667); // 667 = Đã xử lý
      if (t.targetKetThuc) {
        pvm.onKetThucChanged(key, t.targetKetThuc);
      }
    }

    // Xác thực
    if (typeof pvm.validateControls === 'function') {
      const err = pvm.validateControls();
      if (err) {
        return { success: false, error: 'Lỗi xác thực dữ liệu trên form: ' + err };
      }
    }

    // Ghi lại vào hệ thống
    if (typeof pvm.onGhiLai === 'function') {
      await pvm.onGhiLai();
    }

    return {
      success: true,
      updatedCount: tasksToUpdate.length,
      tasks: leadTasks.map(t => ({
        thuTu: t.thuTu,
        tenCongViec: t.tenCongViec,
        trangThai: 'Đã xử lý',
        ketThuc: t.targetKetThuc || t.ketThucHienTai,
        isUpdated: t.needsUpdate
      })),
      message: `Đã cập nhật thành công ${tasksToUpdate.length}/${leadTasks.length} việc Chủ trì (ca ${shiftDate}) sang Đã xử lý (+1h).`
    };
  }

  async function autoFindAndProcess(keyword) {
    const currentHash = window.location.hash || '';
    const timeInfo = getVNTimeInfo();
    const targetDateStr = timeInfo.hours < 8 ? timeInfo.yesterdayStr : timeInfo.todayStr;

    // Nếu đang ở chi tiết ca trực:
    if (currentHash.includes('chi-tiet-thong-tin-ca-truc')) {
      const pvm = findPvm();
      const currentShiftDate = getShiftDate(pvm);

      // Nếu ca đang mở khớp đúng ngày cần xử lý (hôm nay hoặc hôm qua ca đêm):
      if (currentShiftDate === targetDateStr || currentShiftDate === timeInfo.todayStr) {
        console.log(`[OneBSS Auto] Ca trực đang mở khớp ngày ${currentShiftDate}, tiến hành xử lý...`);
        return await processDetailTasks(keyword);
      }

      console.log(`[OneBSS Auto] Ca đang mở là ngày cũ (${currentShiftDate}), chuyển về danh sách ca để tìm ca ngày ${targetDateStr}...`);
      window.location.hash = '#/ha-tang/ds-thong-tin-ca-truc';
      await new Promise(r => setTimeout(r, 1500));
    }

    // Nếu chưa ở trang danh sách, chuyển hướng về danh sách ca trực
    if (!window.location.hash.includes('ds-thong-tin-ca-truc')) {
      window.location.hash = '#/ha-tang/ds-thong-tin-ca-truc';
      await new Promise(r => setTimeout(r, 1500));
    }

    // Thiết lập bộ lọc ngày trên trang danh sách ca trực
    const searchDateFrom = timeInfo.hours < 8 ? timeInfo.yesterdayStr : timeInfo.todayStr;
    const searchDateTo = timeInfo.todayStr;

    for (let retry = 0; retry < 5; retry++) {
      const dateInputFrom = document.querySelector('input[name="ej2-datepicker_6"]') ||
                            document.querySelectorAll('.e-datepicker input')[0];
      const dateInputTo = document.querySelector('input[name="ej2-datepicker_7"]') ||
                          document.querySelectorAll('.e-datepicker input')[1];

      if (dateInputFrom && dateInputTo) {
        if (dateInputFrom.value !== searchDateFrom || dateInputTo.value !== searchDateTo) {
          console.log(`[OneBSS Auto] Thiết lập bộ lọc ngày: ${searchDateFrom} -> ${searchDateTo}`);
          dateInputFrom.value = searchDateFrom;
          dateInputFrom.dispatchEvent(new Event('input', { bubbles: true }));
          dateInputFrom.dispatchEvent(new Event('change', { bubbles: true }));

          dateInputTo.value = searchDateTo;
          dateInputTo.dispatchEvent(new Event('input', { bubbles: true }));
          dateInputTo.dispatchEvent(new Event('change', { bubbles: true }));

          const searchBtn = document.querySelector('a:has(.one-search), button:has(.one-search), .one-search');
          if (searchBtn) {
            const clickTarget = searchBtn.closest('a, button') || searchBtn;
            clickTarget.click();
            await new Promise(r => setTimeout(r, 2000));
          }
        }
        break;
      }
      await new Promise(r => setTimeout(r, 1000));
    }

    // Chờ grid danh sách tải
    const maxWait = 20;
    let foundShift = null;

    for (let i = 0; i < maxWait; i++) {
      await new Promise(r => setTimeout(r, 1000));
      const gridEl = document.querySelector('.grid-ext');
      if (gridEl) {
        const vm = findVue(gridEl);
        if (vm) {
          const ds = (vm.ej2Instances && vm.ej2Instances.dataSource) || vm.dataSource || [];
          if (Array.isArray(ds) && ds.length > 0) {
            const kw = keyword.toLowerCase();
            const matches = ds.filter(item => {
              const str = JSON.stringify(item).toLowerCase();
              return str.includes(kw) || str.includes('vnpt031453');
            });

            if (matches.length > 0) {
              // Sắp xếp ưu tiên:
              // 1. Ngày trực mới nhất (theo parseDateDDMMYYYY)
              // 2. ID ca trực lớn nhất
              matches.sort((a, b) => {
                const dateA = parseDateDDMMYYYY(a.ngayTruc || a.ngay_truc || '');
                const dateB = parseDateDDMMYYYY(b.ngayTruc || b.ngay_truc || '');
                if (dateB !== dateA) return dateB - dateA;
                return (b.id || 0) - (a.id || 0);
              });

              // Tìm ca khớp đúng ngày hiện tại hoặc hôm qua
              const matchCurrent = matches.find(m => {
                const d = m.ngayTruc || m.ngay_truc || '';
                return d === timeInfo.todayStr || d === timeInfo.yesterdayStr;
              });

              foundShift = matchCurrent || matches[0];
              break;
            }
          }
        }
      }
    }

    if (!foundShift || !foundShift.id) {
      return {
        success: false,
        error: `Không tìm thấy ca trực nào của "${keyword}" cho ngày hiện tại (${searchDateFrom} -> ${searchDateTo}). Hãy kiểm tra bộ lọc ngày trên trang danh sách ca trực.`
      };
    }

    console.log(`[OneBSS Auto] Đã chọn ca trực: ID ${foundShift.id}, Ngày: ${foundShift.ngayTruc || 'Chưa rõ'}`);

    // Chuyển hướng tới chi tiết ca trực vừa tìm được
    window.location.hash = `#/ha-tang/chi-tiet-thong-tin-ca-truc/${foundShift.id}`;

    // Chờ trang chi tiết tải xong
    for (let i = 0; i < 20; i++) {
      await new Promise(r => setTimeout(r, 1000));
      const pvm = findPvm();
      if (pvm && Array.isArray(pvm.dsCongViec) && pvm.dsCongViec.length > 0) {
        break;
      }
    }

    // Thực hiện cập nhật
    return await processDetailTasks(keyword);
  }

  // Lắng nghe lệnh từ content-bridge
  window.addEventListener('message', async (event) => {
    if (event.source !== window || !event.data || event.data.source !== 'ONEBSS_BRIDGE') return;

    const { action, requestId, payload } = event.data;

    try {
      if (action === 'PROCESS_DETAIL') {
        const res = await processDetailTasks(payload.keyword);
        window.postMessage({ source: 'ONEBSS_INJECTED', requestId, ...res }, '*');
      } else if (action === 'AUTO_FIND_PROCESS') {
        const res = await autoFindAndProcess(payload.keyword);
        window.postMessage({ source: 'ONEBSS_INJECTED', requestId, ...res }, '*');
      } else if (action === 'GET_PAGE_INFO') {
        const pvm = findPvm();
        const hash = window.location.hash || '';
        window.postMessage({
          source: 'ONEBSS_INJECTED',
          requestId,
          success: true,
          hash: hash,
          isDetailPage: hash.includes('chi-tiet-thong-tin-ca-truc'),
          hasPvm: !!pvm,
          taskCount: pvm && pvm.dsCongViec ? pvm.dsCongViec.length : 0
        }, '*');
      }
    } catch (err) {
      window.postMessage({
        source: 'ONEBSS_INJECTED',
        requestId,
        success: false,
        error: err.message || String(err)
      }, '*');
    }
  });
})();
